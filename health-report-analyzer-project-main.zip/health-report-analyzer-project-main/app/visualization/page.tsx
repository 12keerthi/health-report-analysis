"use client"

import { useEffect, useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { ArrowLeft, BarChart3, TrendingUp } from "lucide-react"
import Link from "next/link"
import { useRouter } from "next/navigation"
import {
  Bar,
  BarChart,
  Cell,
  Pie,
  PieChart as RechartsPieChart,
  ResponsiveContainer,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
} from "recharts"
import { ChartContainer } from "@/components/ui/chart"

interface HealthData {
  patientId: string
  bloodPressure: string
  glucose: string
  cholesterol: string
  age: string
  symptoms?: string
}

interface ChartData {
  parameter: string
  userValue: number
  normalValue: number
  status: string
}

export default function VisualizationPage() {
  const [healthData, setHealthData] = useState<HealthData[]>([])
  const [currentPatient, setCurrentPatient] = useState(0)
  const [loading, setLoading] = useState(true)
  const router = useRouter()

  useEffect(() => {
    const storedData = localStorage.getItem("healthData")
    if (storedData) {
      setHealthData(JSON.parse(storedData))
    } else {
      router.push("/")
    }
    setLoading(false)
  }, [router])

  if (loading) {
    return <div className="min-h-screen bg-background flex items-center justify-center">Loading...</div>
  }

  if (healthData.length === 0) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <Card className="max-w-md">
          <CardHeader>
            <CardTitle>No Data Found</CardTitle>
            <CardDescription>Please upload or enter health data first.</CardDescription>
          </CardHeader>
          <CardContent>
            <Button asChild>
              <Link href="/">Go Back Home</Link>
            </Button>
          </CardContent>
        </Card>
      </div>
    )
  }

  const patient = healthData[currentPatient]

  // Prepare chart data
  const prepareChartData = (): ChartData[] => {
    const [systolic] = patient.bloodPressure.split("/").map(Number)
    const glucose = Number(patient.glucose)
    const cholesterol = Number(patient.cholesterol)

    return [
      {
        parameter: "Blood Pressure",
        userValue: systolic,
        normalValue: 120,
        status: systolic >= 140 ? "high" : systolic >= 130 ? "borderline" : "normal",
      },
      {
        parameter: "Glucose",
        userValue: glucose,
        normalValue: 100,
        status: glucose >= 126 ? "high" : glucose >= 100 ? "borderline" : "normal",
      },
      {
        parameter: "Cholesterol",
        userValue: cholesterol,
        normalValue: 200,
        status: cholesterol >= 240 ? "high" : cholesterol >= 200 ? "borderline" : "normal",
      },
    ]
  }

  const chartData = prepareChartData()

  // Prepare pie chart data for risk factors
  const preparePieData = () => {
    const riskFactors = chartData.filter((item) => item.status === "high" || item.status === "borderline").length
    const healthyFactors = chartData.length - riskFactors

    return [
      {
        name: "Risk Factors",
        value: riskFactors,
        percentage: Math.round((riskFactors / chartData.length) * 100),
        color: "hsl(var(--chart-4))",
      },
      {
        name: "Healthy Parameters",
        value: healthyFactors,
        percentage: Math.round((healthyFactors / chartData.length) * 100),
        color: "hsl(var(--chart-1))",
      },
    ]
  }

  const pieData = preparePieData()

  const getBarColor = (status: string) => {
    switch (status) {
      case "high":
        return "hsl(var(--chart-4))"
      case "borderline":
        return "hsl(var(--chart-3))"
      case "normal":
        return "hsl(var(--chart-1))"
      default:
        return "hsl(var(--chart-2))"
    }
  }

  const CustomTooltip = ({ active, payload, label }: any) => {
    if (active && payload && payload.length) {
      return (
        <div className="bg-background border border-border rounded-lg p-3 shadow-lg">
          <p className="font-semibold">{label}</p>
          <p className="text-primary">
            Your Value: <span className="font-mono">{payload[0].value}</span>
          </p>
          <p className="text-muted-foreground">
            Normal: <span className="font-mono">{payload[1].value}</span>
          </p>
        </div>
      )
    }
    return null
  }

  const CustomPieTooltip = ({ active, payload }: any) => {
    if (active && payload && payload.length) {
      return (
        <div className="bg-background border border-border rounded-lg p-3 shadow-lg">
          <p className="font-semibold">{payload[0].name}</p>
          <p className="text-primary">
            Count: <span className="font-mono">{payload[0].value}</span>
          </p>
          <p className="text-muted-foreground">
            Percentage: <span className="font-mono">{payload[0].payload.percentage}%</span>
          </p>
        </div>
      )
    }
    return null
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b bg-card/50 backdrop-blur-sm">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <Button variant="ghost" size="sm" asChild>
                <Link href="/analysis">
                  <ArrowLeft className="h-4 w-4 mr-2" />
                  Back to Analysis
                </Link>
              </Button>
              <h1 className="text-2xl font-bold text-foreground">Health Visualizations</h1>
            </div>
            {healthData.length > 1 && (
              <div className="flex items-center gap-2">
                <span className="text-sm text-muted-foreground">Patient:</span>
                <select
                  value={currentPatient}
                  onChange={(e) => setCurrentPatient(Number(e.target.value))}
                  className="px-3 py-1 border rounded-md bg-background"
                >
                  {healthData.map((_, index) => (
                    <option key={index} value={index}>
                      {healthData[index].patientId}
                    </option>
                  ))}
                </select>
              </div>
            )}
          </div>
        </div>
      </header>

      <main className="container mx-auto px-4 py-8 max-w-7xl">
        {/* Patient Info */}
        <Card className="mb-8">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <BarChart3 className="h-6 w-6 text-primary" />
              Health Data Visualization
            </CardTitle>
            <CardDescription>
              Patient ID: {patient.patientId} | Age: {patient.age} years
            </CardDescription>
          </CardHeader>
        </Card>

        <div className="grid lg:grid-cols-2 gap-8">
          {/* Bar Chart - Comparison with Normal Values */}
          <Card>
            <CardHeader>
              <CardTitle>Parameter Comparison</CardTitle>
              <CardDescription>Your values compared to normal ranges</CardDescription>
            </CardHeader>
            <CardContent>
              <ChartContainer
                config={{
                  userValue: {
                    label: "Your Value",
                    color: "hsl(var(--chart-1))",
                  },
                  normalValue: {
                    label: "Normal Value",
                    color: "hsl(var(--chart-2))",
                  },
                }}
                className="h-[400px]"
              >
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={chartData} margin={{ top: 20, right: 30, left: 20, bottom: 5 }}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis
                      dataKey="parameter"
                      tick={{ fontSize: 12 }}
                      interval={0}
                      angle={-45}
                      textAnchor="end"
                      height={80}
                    />
                    <YAxis />
                    <Tooltip content={<CustomTooltip />} />
                    <Legend />
                    <Bar dataKey="userValue" name="Your Value" radius={[4, 4, 0, 0]}>
                      {chartData.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={getBarColor(entry.status)} />
                      ))}
                    </Bar>
                    <Bar dataKey="normalValue" name="Normal Value" fill="hsl(var(--chart-2))" radius={[4, 4, 0, 0]} />
                  </BarChart>
                </ResponsiveContainer>
              </ChartContainer>
            </CardContent>
          </Card>

          {/* Pie Chart - Risk Factors vs Healthy */}
          <Card>
            <CardHeader>
              <CardTitle>Health Status Overview</CardTitle>
              <CardDescription>Distribution of healthy vs risk parameters</CardDescription>
            </CardHeader>
            <CardContent>
              <ChartContainer
                config={{
                  riskFactors: {
                    label: "Risk Factors",
                    color: "hsl(var(--chart-4))",
                  },
                  healthy: {
                    label: "Healthy Parameters",
                    color: "hsl(var(--chart-1))",
                  },
                }}
                className="h-[400px]"
              >
                <ResponsiveContainer width="100%" height="100%">
                  <RechartsPieChart>
                    <Pie
                      data={pieData}
                      cx="50%"
                      cy="50%"
                      labelLine={false}
                      label={({ name, percentage }) => `${name}: ${percentage}%`}
                      outerRadius={120}
                      fill="#8884d8"
                      dataKey="value"
                    >
                      {pieData.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={entry.color} />
                      ))}
                    </Pie>
                    <Tooltip content={<CustomPieTooltip />} />
                    <Legend />
                  </RechartsPieChart>
                </ResponsiveContainer>
              </ChartContainer>
            </CardContent>
          </Card>
        </div>

        {/* Detailed Metrics Cards */}
        <div className="grid md:grid-cols-3 gap-6 mt-8">
          {chartData.map((item, index) => (
            <Card key={index}>
              <CardHeader className="pb-3">
                <CardTitle className="text-lg">{item.parameter}</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  <div className="flex justify-between items-center">
                    <span className="text-sm text-muted-foreground">Your Value:</span>
                    <span className="font-mono font-semibold text-lg">{item.userValue}</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-sm text-muted-foreground">Normal:</span>
                    <span className="font-mono text-muted-foreground">
                      {item.parameter === "Cholesterol" ? "<200" : `≤${item.normalValue}`}
                    </span>
                  </div>
                  <div className="pt-2">
                    <div
                      className={`px-3 py-1 rounded-full text-xs font-medium text-center ${
                        item.status === "high"
                          ? "bg-destructive/10 text-destructive"
                          : item.status === "borderline"
                            ? "bg-yellow-100 text-yellow-800"
                            : "bg-primary/10 text-primary"
                      }`}
                    >
                      {item.status.charAt(0).toUpperCase() + item.status.slice(1)}
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Navigation */}
        <div className="flex flex-col sm:flex-row gap-4 justify-center mt-8">
          <Button asChild size="lg">
            <Link href="/summary">
              <TrendingUp className="mr-2 h-5 w-5" />
              Generate Summary Report
            </Link>
          </Button>
          <Button asChild variant="outline" size="lg">
            <Link href="/analysis">Back to Analysis</Link>
          </Button>
        </div>
      </main>
    </div>
  )
}
