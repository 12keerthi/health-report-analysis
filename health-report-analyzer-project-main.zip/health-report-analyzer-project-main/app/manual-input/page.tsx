"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { ArrowLeft, User } from "lucide-react"
import Link from "next/link"
import { useRouter } from "next/navigation"

interface ManualHealthData {
  patientId: string
  bloodPressure: string
  glucose: string
  cholesterol: string
  age: string
  symptoms: string
}

export default function ManualInputPage() {
  const [formData, setFormData] = useState<ManualHealthData>({
    patientId: "",
    bloodPressure: "",
    glucose: "",
    cholesterol: "",
    age: "",
    symptoms: "",
  })
  const [errors, setErrors] = useState<Partial<ManualHealthData>>({})
  const router = useRouter()

  const handleInputChange = (field: keyof ManualHealthData, value: string) => {
    setFormData((prev) => ({ ...prev, [field]: value }))
    // Clear error when user starts typing
    if (errors[field]) {
      setErrors((prev) => ({ ...prev, [field]: "" }))
    }
  }

  const validateForm = () => {
    const newErrors: Partial<ManualHealthData> = {}

    if (!formData.patientId.trim()) newErrors.patientId = "Patient ID is required"
    if (!formData.bloodPressure.trim()) newErrors.bloodPressure = "Blood pressure is required"
    if (!formData.glucose.trim()) newErrors.glucose = "Glucose level is required"
    if (!formData.cholesterol.trim()) newErrors.cholesterol = "Cholesterol level is required"
    if (!formData.age.trim()) newErrors.age = "Age is required"

    // Validate blood pressure format (basic)
    if (formData.bloodPressure && !/^\d+\/\d+$/.test(formData.bloodPressure)) {
      newErrors.bloodPressure = "Please use format: 120/80"
    }

    // Validate numeric fields
    if (formData.glucose && isNaN(Number(formData.glucose))) {
      newErrors.glucose = "Please enter a valid number"
    }
    if (formData.cholesterol && isNaN(Number(formData.cholesterol))) {
      newErrors.cholesterol = "Please enter a valid number"
    }
    if (formData.age && isNaN(Number(formData.age))) {
      newErrors.age = "Please enter a valid number"
    }

    setErrors(newErrors)
    return Object.keys(newErrors).length === 0
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    if (validateForm()) {
      // Convert to array format for consistency with CSV upload
      const healthData = [formData]
      localStorage.setItem("healthData", JSON.stringify(healthData))
      router.push("/analysis")
    }
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b bg-card/50 backdrop-blur-sm">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center gap-4">
            <Button variant="ghost" size="sm" asChild>
              <Link href="/">
                <ArrowLeft className="h-4 w-4 mr-2" />
                Back
              </Link>
            </Button>
            <h1 className="text-2xl font-bold text-foreground">Enter Health Data</h1>
          </div>
        </div>
      </header>

      <main className="container mx-auto px-4 py-8 max-w-2xl">
        <Card>
          <CardHeader>
            <div className="flex items-center gap-2">
              <User className="h-6 w-6 text-primary" />
              <CardTitle>Manual Health Data Entry</CardTitle>
            </div>
            <CardDescription>Enter your health parameters manually for AI analysis</CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-6">
              {/* Patient ID */}
              <div className="space-y-2">
                <Label htmlFor="patientId">Patient ID</Label>
                <Input
                  id="patientId"
                  placeholder="e.g., 101"
                  value={formData.patientId}
                  onChange={(e) => handleInputChange("patientId", e.target.value)}
                  className={errors.patientId ? "border-destructive" : ""}
                />
                {errors.patientId && <p className="text-sm text-destructive">{errors.patientId}</p>}
              </div>

              {/* Blood Pressure */}
              <div className="space-y-2">
                <Label htmlFor="bloodPressure">Blood Pressure</Label>
                <Input
                  id="bloodPressure"
                  placeholder="e.g., 120/80"
                  value={formData.bloodPressure}
                  onChange={(e) => handleInputChange("bloodPressure", e.target.value)}
                  className={errors.bloodPressure ? "border-destructive" : ""}
                />
                {errors.bloodPressure && <p className="text-sm text-destructive">{errors.bloodPressure}</p>}
                <p className="text-sm text-muted-foreground">Format: systolic/diastolic (e.g., 120/80)</p>
              </div>

              {/* Glucose */}
              <div className="space-y-2">
                <Label htmlFor="glucose">Glucose Level (mg/dL)</Label>
                <Input
                  id="glucose"
                  placeholder="e.g., 95"
                  value={formData.glucose}
                  onChange={(e) => handleInputChange("glucose", e.target.value)}
                  className={errors.glucose ? "border-destructive" : ""}
                />
                {errors.glucose && <p className="text-sm text-destructive">{errors.glucose}</p>}
                <p className="text-sm text-muted-foreground">Normal range: 70-140 mg/dL</p>
              </div>

              {/* Cholesterol */}
              <div className="space-y-2">
                <Label htmlFor="cholesterol">Cholesterol Level (mg/dL)</Label>
                <Input
                  id="cholesterol"
                  placeholder="e.g., 180"
                  value={formData.cholesterol}
                  onChange={(e) => handleInputChange("cholesterol", e.target.value)}
                  className={errors.cholesterol ? "border-destructive" : ""}
                />
                {errors.cholesterol && <p className="text-sm text-destructive">{errors.cholesterol}</p>}
                <p className="text-sm text-muted-foreground">Desirable: {"<200 mg/dL"}</p>
              </div>

              {/* Age */}
              <div className="space-y-2">
                <Label htmlFor="age">Age</Label>
                <Input
                  id="age"
                  placeholder="e.g., 45"
                  value={formData.age}
                  onChange={(e) => handleInputChange("age", e.target.value)}
                  className={errors.age ? "border-destructive" : ""}
                />
                {errors.age && <p className="text-sm text-destructive">{errors.age}</p>}
              </div>

              {/* Symptoms */}
              <div className="space-y-2">
                <Label htmlFor="symptoms">Symptoms (Optional)</Label>
                <Textarea
                  id="symptoms"
                  placeholder="Describe any symptoms you're experiencing..."
                  value={formData.symptoms}
                  onChange={(e) => handleInputChange("symptoms", e.target.value)}
                  rows={3}
                />
                <p className="text-sm text-muted-foreground">Include any relevant symptoms or health concerns</p>
              </div>

              {/* Submit Button */}
              <div className="flex gap-4 pt-4">
                <Button type="submit" size="lg" className="flex-1">
                  Analyze Health Data
                </Button>
                <Button type="button" variant="outline" asChild>
                  <Link href="/upload">Upload CSV Instead</Link>
                </Button>
              </div>
            </form>
          </CardContent>
        </Card>

        {/* Reference Ranges Card */}
        <Card className="mt-8">
          <CardHeader>
            <CardTitle>Normal Reference Ranges</CardTitle>
            <CardDescription>Use these ranges as a reference when entering your data</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid sm:grid-cols-2 gap-4 text-sm">
              <div>
                <strong>Blood Pressure:</strong>
                <ul className="mt-1 space-y-1 text-muted-foreground">
                  <li>Normal: {"<120/80"}</li>
                  <li>Elevated: 120-129/{"<80"}</li>
                  <li>High: {"≥130/80"}</li>
                </ul>
              </div>
              <div>
                <strong>Glucose (Fasting):</strong>
                <ul className="mt-1 space-y-1 text-muted-foreground">
                  <li>Normal: 70-100 mg/dL</li>
                  <li>Prediabetes: 100-125 mg/dL</li>
                  <li>Diabetes: {"≥126 mg/dL"}</li>
                </ul>
              </div>
              <div>
                <strong>Total Cholesterol:</strong>
                <ul className="mt-1 space-y-1 text-muted-foreground">
                  <li>Desirable: {"<200 mg/dL"}</li>
                  <li>Borderline: 200-239 mg/dL</li>
                  <li>High: {"≥240 mg/dL"}</li>
                </ul>
              </div>
            </div>
          </CardContent>
        </Card>
      </main>
    </div>
  )
}
