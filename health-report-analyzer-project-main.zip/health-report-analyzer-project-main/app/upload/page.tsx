"use client"

import type React from "react"
import { useEffect } from "react"
import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Upload, FileText, ArrowLeft, CheckCircle } from "lucide-react"
import Link from "next/link"
import { useRouter } from "next/navigation"

interface HealthData {
  patientId: string
  bloodPressure: string
  glucose: string
  cholesterol: string
  age: string
}

export default function UploadPage() {
  const [file, setFile] = useState<File | null>(null)
  const [dragActive, setDragActive] = useState(false)
  const [uploadSuccess, setUploadSuccess] = useState(false)
  const [healthData, setHealthData] = useState<HealthData[]>([])
  const router = useRouter()

  useEffect(() => {
    const isLoggedIn = localStorage.getItem("isLoggedIn")
    if (!isLoggedIn) {
      router.push("/login")
    }
  }, [router])

  const handleDrag = (e: React.DragEvent) => {
    e.preventDefault()
    e.stopPropagation()
    if (e.type === "dragenter" || e.type === "dragover") {
      setDragActive(true)
    } else if (e.type === "dragleave") {
      setDragActive(false)
    }
  }

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault()
    e.stopPropagation()
    setDragActive(false)

    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      handleFile(e.dataTransfer.files[0])
    }
  }

  const handleFileInput = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      handleFile(e.target.files[0])
    }
  }

  const triggerFileInput = () => {
    const fileInput = document.getElementById("file-upload") as HTMLInputElement
    if (fileInput) {
      fileInput.click()
    }
  }

  const handleFile = (selectedFile: File) => {
    if (selectedFile.type === "text/csv" || selectedFile.name.endsWith(".csv")) {
      setFile(selectedFile)
      parseCSV(selectedFile)
    } else {
      alert("Please upload a CSV file")
    }
  }

  const parseCSV = (file: File) => {
    const reader = new FileReader()
    reader.onload = (e) => {
      const text = e.target?.result as string
      const lines = text.split("\n")
      const headers = lines[0].split(",").map((h) => h.trim().toLowerCase())

      const data: HealthData[] = []
      for (let i = 1; i < lines.length; i++) {
        if (lines[i].trim()) {
          const values = lines[i].split(",").map((v) => v.trim())
          data.push({
            patientId: values[0] || "",
            bloodPressure: values[1] || "",
            glucose: values[2] || "",
            cholesterol: values[3] || "",
            age: values[4] || "",
          })
        }
      }
      setHealthData(data)
      setUploadSuccess(true)
    }
    reader.readAsText(file)
  }

  const handleAnalyze = () => {
    // Store data in localStorage for the analysis page
    localStorage.setItem("healthData", JSON.stringify(healthData))
    router.push("/analysis")
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b bg-card/50 backdrop-blur-sm">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center gap-4">
            <Button variant="ghost" size="sm" asChild>
              <Link href="/dashboard">
                <ArrowLeft className="h-4 w-4 mr-2" />
                Back
              </Link>
            </Button>
            <h1 className="text-2xl font-bold text-foreground">Upload Health Report</h1>
          </div>
        </div>
      </header>

      <main className="container mx-auto px-4 py-8 max-w-4xl">
        {!uploadSuccess ? (
          <>
            {/* Upload Section */}
            <Card className="mb-8">
              <CardHeader>
                <CardTitle>Upload CSV File</CardTitle>
                <CardDescription>
                  Upload a CSV file with columns: Patient ID, Blood Pressure, Glucose, Cholesterol, Age
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div
                  className={`border-2 border-dashed rounded-lg p-8 text-center transition-colors cursor-pointer ${
                    dragActive
                      ? "border-primary bg-primary/5"
                      : "border-border hover:border-primary/50 hover:bg-primary/5"
                  }`}
                  onDragEnter={handleDrag}
                  onDragLeave={handleDrag}
                  onDragOver={handleDrag}
                  onDrop={handleDrop}
                  onClick={triggerFileInput}
                >
                  <Upload className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
                  <p className="text-lg font-medium mb-2">Drop your CSV file here</p>
                  <p className="text-muted-foreground mb-4">or click to browse</p>
                  <Input type="file" accept=".csv" onChange={handleFileInput} className="hidden" id="file-upload" />
                  <Button variant="outline" className="pointer-events-none bg-transparent">
                    Choose File
                  </Button>
                </div>
                {file && (
                  <div className="mt-4 p-3 bg-secondary rounded-lg">
                    <p className="text-sm">
                      <strong>Selected file:</strong> {file.name}
                    </p>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Sample CSV Format */}
            <Card>
              <CardHeader>
                <CardTitle>Expected CSV Format</CardTitle>
                <CardDescription>Your CSV file should follow this structure</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="bg-muted p-4 rounded-lg font-mono text-sm overflow-x-auto">
                  <div className="whitespace-nowrap">
                    Patient ID, Blood Pressure, Glucose, Cholesterol, Age
                    <br />
                    101, 150/95, 180, 220, 45
                    <br />
                    102, 120/80, 95, 180, 32
                    <br />
                    103, 140/90, 110, 200, 55
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Alternative Option */}
            <div className="text-center mt-8">
              <p className="text-muted-foreground mb-4">Don't have a CSV file?</p>
              <Button variant="outline" asChild>
                <Link href="/manual-input">
                  <FileText className="mr-2 h-4 w-4" />
                  Enter Data Manually
                </Link>
              </Button>
            </div>
          </>
        ) : (
          /* Success State */
          <Card>
            <CardHeader className="text-center">
              <CheckCircle className="h-16 w-16 text-primary mx-auto mb-4" />
              <CardTitle>File Uploaded Successfully!</CardTitle>
              <CardDescription>
                We've processed {healthData.length} health record{healthData.length !== 1 ? "s" : ""} from your CSV
                file.
              </CardDescription>
            </CardHeader>
            <CardContent>
              {/* Preview of uploaded data */}
              <div className="mb-6">
                <h3 className="font-semibold mb-3">Data Preview:</h3>
                <div className="overflow-x-auto">
                  <table className="w-full border-collapse border border-border rounded-lg">
                    <thead>
                      <tr className="bg-muted">
                        <th className="border border-border p-3 text-left">Patient ID</th>
                        <th className="border border-border p-3 text-left">Blood Pressure</th>
                        <th className="border border-border p-3 text-left">Glucose</th>
                        <th className="border border-border p-3 text-left">Cholesterol</th>
                        <th className="border border-border p-3 text-left">Age</th>
                      </tr>
                    </thead>
                    <tbody>
                      {healthData.slice(0, 3).map((row, index) => (
                        <tr key={index}>
                          <td className="border border-border p-3">{row.patientId}</td>
                          <td className="border border-border p-3">{row.bloodPressure}</td>
                          <td className="border border-border p-3">{row.glucose}</td>
                          <td className="border border-border p-3">{row.cholesterol}</td>
                          <td className="border border-border p-3">{row.age}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                  {healthData.length > 3 && (
                    <p className="text-sm text-muted-foreground mt-2">
                      ... and {healthData.length - 3} more record{healthData.length - 3 !== 1 ? "s" : ""}
                    </p>
                  )}
                </div>
              </div>

              <div className="flex gap-4 justify-center">
                <Button onClick={handleAnalyze} size="lg">
                  Analyze Health Data
                </Button>
                <Button
                  variant="outline"
                  onClick={() => {
                    setUploadSuccess(false)
                    setFile(null)
                    setHealthData([])
                  }}
                >
                  Upload Different File
                </Button>
              </div>
            </CardContent>
          </Card>
        )}
      </main>
    </div>
  )
}
