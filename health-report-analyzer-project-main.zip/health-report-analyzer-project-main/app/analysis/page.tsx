"use client"

import { useEffect, useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { ArrowLeft, AlertTriangle, CheckCircle, TrendingUp, Activity } from "lucide-react"
import Link from "next/link"
import { useRouter } from "next/navigation"

interface HealthData {
  patientId: string
  bloodPressure: string
  glucose: string
  cholesterol: string
  age: string
  symptoms?: string
}

interface HealthParameter {
  name: string
  value: string
  normalRange: string
  status: "normal" | "borderline" | "high" | "low"
  numericValue?: number
}

interface RiskPrediction {
  condition: string
  risk: "low" | "moderate" | "high"
  confidence: number
  description: string
}

export default function AnalysisPage() {
  const [healthData, setHealthData] = useState<HealthData[]>([])
  const [currentPatient, setCurrentPatient] = useState(0)
  const [loading, setLoading] = useState(true)
  const router = useRouter()

  useEffect(() => {
    const storedData = localStorage.getItem("healthData")
    if (storedData) {
      setHealthData(JSON.parse(storedData))
    } else {
      router.push("/")
    }
    setLoading(false)
  }, [router])

  if (loading) {
    return <div className="min-h-screen bg-background flex items-center justify-center">Loading...</div>
  }

  if (healthData.length === 0) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <Card className="max-w-md">
          <CardHeader>
            <CardTitle>No Data Found</CardTitle>
            <CardDescription>Please upload or enter health data first.</CardDescription>
          </CardHeader>
          <CardContent>
            <Button asChild>
              <Link href="/">Go Back Home</Link>
            </Button>
          </CardContent>
        </Card>
      </div>
    )
  }

  const patient = healthData[currentPatient]

  // Analyze health parameters
  const analyzeParameter = (value: string, type: string): HealthParameter => {
    switch (type) {
      case "bloodPressure":
        const [systolic, diastolic] = value.split("/").map(Number)
        let bpStatus: "normal" | "borderline" | "high" = "normal"
        if (systolic >= 140 || diastolic >= 90) bpStatus = "high"
        else if (systolic >= 130 || diastolic >= 80) bpStatus = "borderline"

        return {
          name: "Blood Pressure",
          value: value,
          normalRange: "<120/80",
          status: bpStatus,
          numericValue: systolic,
        }

      case "glucose":
        const glucoseNum = Number(value)
        let glucoseStatus: "normal" | "borderline" | "high" = "normal"
        if (glucoseNum >= 126) glucoseStatus = "high"
        else if (glucoseNum >= 100) glucoseStatus = "borderline"

        return {
          name: "Glucose",
          value: `${value} mg/dL`,
          normalRange: "70-100 mg/dL",
          status: glucoseStatus,
          numericValue: glucoseNum,
        }

      case "cholesterol":
        const cholesterolNum = Number(value)
        let cholesterolStatus: "normal" | "borderline" | "high" = "normal"
        if (cholesterolNum >= 240) cholesterolStatus = "high"
        else if (cholesterolNum >= 200) cholesterolStatus = "borderline"

        return {
          name: "Cholesterol",
          value: `${value} mg/dL`,
          normalRange: "<200 mg/dL",
          status: cholesterolStatus,
          numericValue: cholesterolNum,
        }

      default:
        return {
          name: type,
          value: value,
          normalRange: "N/A",
          status: "normal",
        }
    }
  }

  const parameters = [
    analyzeParameter(patient.bloodPressure, "bloodPressure"),
    analyzeParameter(patient.glucose, "glucose"),
    analyzeParameter(patient.cholesterol, "cholesterol"),
  ]

  // Generate AI predictions (simulated)
  const generatePredictions = (): RiskPrediction[] => {
    const predictions: RiskPrediction[] = []

    // Blood pressure analysis
    const bpParam = parameters.find((p) => p.name === "Blood Pressure")
    if (bpParam && bpParam.numericValue && bpParam.numericValue >= 140) {
      predictions.push({
        condition: "Hypertension",
        risk: "high",
        confidence: 92,
        description: "Elevated blood pressure indicates high risk of hypertension",
      })
    } else if (bpParam && bpParam.numericValue && bpParam.numericValue >= 130) {
      predictions.push({
        condition: "Hypertension",
        risk: "moderate",
        confidence: 75,
        description: "Blood pressure is in the elevated range",
      })
    }

    // Glucose analysis
    const glucoseParam = parameters.find((p) => p.name === "Glucose")
    if (glucoseParam && glucoseParam.numericValue && glucoseParam.numericValue >= 126) {
      predictions.push({
        condition: "Diabetes",
        risk: "high",
        confidence: 85,
        description: "Glucose levels suggest possible diabetes",
      })
    } else if (glucoseParam && glucoseParam.numericValue && glucoseParam.numericValue >= 100) {
      predictions.push({
        condition: "Prediabetes",
        risk: "moderate",
        confidence: 70,
        description: "Glucose levels indicate prediabetes risk",
      })
    }

    // Cholesterol analysis
    const cholesterolParam = parameters.find((p) => p.name === "Cholesterol")
    if (cholesterolParam && cholesterolParam.numericValue && cholesterolParam.numericValue >= 240) {
      predictions.push({
        condition: "Heart Disease",
        risk: "moderate",
        confidence: 65,
        description: "High cholesterol increases cardiovascular risk",
      })
    }

    // If no major risks found
    if (predictions.length === 0) {
      predictions.push({
        condition: "Overall Health",
        risk: "low",
        confidence: 88,
        description: "No immediate health risks detected based on current parameters",
      })
    }

    return predictions
  }

  const predictions = generatePredictions()

  const getStatusColor = (status: string) => {
    switch (status) {
      case "high":
        return "bg-destructive/10 text-destructive border-destructive/20"
      case "borderline":
        return "bg-yellow-100 text-yellow-800 border-yellow-200"
      case "normal":
        return "bg-primary/10 text-primary border-primary/20"
      default:
        return "bg-muted text-muted-foreground"
    }
  }

  const getRiskColor = (risk: string) => {
    switch (risk) {
      case "high":
        return "text-destructive"
      case "moderate":
        return "text-yellow-600"
      case "low":
        return "text-primary"
      default:
        return "text-muted-foreground"
    }
  }

  const getRiskIcon = (risk: string) => {
    switch (risk) {
      case "high":
        return <AlertTriangle className="h-5 w-5" />
      case "moderate":
        return <TrendingUp className="h-5 w-5" />
      case "low":
        return <CheckCircle className="h-5 w-5" />
      default:
        return <Activity className="h-5 w-5" />
    }
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b bg-card/50 backdrop-blur-sm">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <Button variant="ghost" size="sm" asChild>
                <Link href="/">
                  <ArrowLeft className="h-4 w-4 mr-2" />
                  Back
                </Link>
              </Button>
              <h1 className="text-2xl font-bold text-foreground">Health Analysis</h1>
            </div>
            {healthData.length > 1 && (
              <div className="flex items-center gap-2">
                <span className="text-sm text-muted-foreground">Patient:</span>
                <select
                  value={currentPatient}
                  onChange={(e) => setCurrentPatient(Number(e.target.value))}
                  className="px-3 py-1 border rounded-md bg-background"
                >
                  {healthData.map((_, index) => (
                    <option key={index} value={index}>
                      {healthData[index].patientId}
                    </option>
                  ))}
                </select>
              </div>
            )}
          </div>
        </div>
      </header>

      <main className="container mx-auto px-4 py-8 max-w-6xl">
        <div className="grid lg:grid-cols-2 gap-8">
          {/* Health Parameters Table */}
          <Card>
            <CardHeader>
              <CardTitle>Health Parameters Analysis</CardTitle>
              <CardDescription>
                Patient ID: {patient.patientId} | Age: {patient.age}
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead>
                    <tr className="border-b">
                      <th className="text-left p-3 font-semibold">Parameter</th>
                      <th className="text-left p-3 font-semibold">Value</th>
                      <th className="text-left p-3 font-semibold">Normal Range</th>
                      <th className="text-left p-3 font-semibold">Status</th>
                    </tr>
                  </thead>
                  <tbody>
                    {parameters.map((param, index) => (
                      <tr key={index} className="border-b">
                        <td className="p-3 font-medium">{param.name}</td>
                        <td className="p-3 font-mono">{param.value}</td>
                        <td className="p-3 text-muted-foreground">{param.normalRange}</td>
                        <td className="p-3">
                          <Badge className={getStatusColor(param.status)}>
                            {param.status.charAt(0).toUpperCase() + param.status.slice(1)}
                          </Badge>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>

              {patient.symptoms && (
                <div className="mt-6 p-4 bg-muted rounded-lg">
                  <h4 className="font-semibold mb-2">Reported Symptoms:</h4>
                  <p className="text-sm text-muted-foreground">{patient.symptoms}</p>
                </div>
              )}
            </CardContent>
          </Card>

          {/* AI Predictions */}
          <Card>
            <CardHeader>
              <CardTitle>AI Risk Predictions</CardTitle>
              <CardDescription>AI-powered health risk assessment based on your data</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              {predictions.map((prediction, index) => (
                <div key={index} className="border rounded-lg p-4">
                  <div className="flex items-start gap-3">
                    <div className={getRiskColor(prediction.risk)}>{getRiskIcon(prediction.risk)}</div>
                    <div className="flex-1">
                      <div className="flex items-center justify-between mb-2">
                        <h4 className="font-semibold">{prediction.condition}</h4>
                        <Badge variant="outline" className={getRiskColor(prediction.risk)}>
                          {prediction.risk.toUpperCase()} RISK
                        </Badge>
                      </div>
                      <p className="text-sm text-muted-foreground mb-3">{prediction.description}</p>
                      <div className="space-y-2">
                        <div className="flex items-center justify-between text-sm">
                          <span>Confidence Level</span>
                          <span className="font-medium">{prediction.confidence}%</span>
                        </div>
                        <Progress value={prediction.confidence} className="h-2" />
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </CardContent>
          </Card>
        </div>

        {/* Action Buttons */}
        <div className="flex flex-col sm:flex-row gap-4 justify-center mt-8">
          <Button asChild size="lg">
            <Link href="/visualization">
              <TrendingUp className="mr-2 h-5 w-5" />
              View Visualizations
            </Link>
          </Button>
          <Button asChild variant="outline" size="lg">
            <Link href="/summary">Generate Summary Report</Link>
          </Button>
        </div>
      </main>
    </div>
  )
}
