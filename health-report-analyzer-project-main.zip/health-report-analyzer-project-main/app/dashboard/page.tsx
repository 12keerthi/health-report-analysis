"use client"

import { useEffect, useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Activity, Upload, BarChart3, FileText, LogOut } from "lucide-react"
import Link from "next/link"
import { useRouter } from "next/navigation"

export default function DashboardPage() {
  const [userEmail, setUserEmail] = useState("")
  const router = useRouter()

  useEffect(() => {
    // Check if user is logged in
    const isLoggedIn = localStorage.getItem("isLoggedIn")
    const email = localStorage.getItem("userEmail")

    if (!isLoggedIn) {
      router.push("/login")
      return
    }

    setUserEmail(email || "")
  }, [router])

  const handleLogout = () => {
    localStorage.removeItem("isLoggedIn")
    localStorage.removeItem("userEmail")
    localStorage.removeItem("healthData") // Clear any stored health data
    router.push("/login")
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b bg-card/50 backdrop-blur-sm">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Activity className="h-8 w-8 text-primary" />
              <h1 className="text-2xl font-bold text-foreground">AI Health Report Analyzer</h1>
            </div>
            <div className="flex items-center gap-4">
              <span className="text-sm text-muted-foreground">Welcome, {userEmail}</span>
              <Button variant="outline" size="sm" onClick={handleLogout}>
                <LogOut className="h-4 w-4 mr-2" />
                Logout
              </Button>
            </div>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <main className="container mx-auto px-4 py-12">
        <div className="text-center mb-12">
          <h2 className="text-4xl font-bold text-balance mb-4">Analyze Your Health Data with AI</h2>
          <p className="text-xl text-muted-foreground text-balance max-w-2xl mx-auto mb-8">
            Upload your health reports or enter data manually to get AI-powered insights, risk predictions, and
            personalized health recommendations.
          </p>

          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button asChild size="lg" className="text-lg px-8">
              <Link href="/upload">
                <Upload className="mr-2 h-5 w-5" />
                Upload Report
              </Link>
            </Button>
            <Button asChild variant="outline" size="lg" className="text-lg px-8 bg-transparent">
              <Link href="/manual-input">
                <FileText className="mr-2 h-5 w-5" />
                Enter Data Manually
              </Link>
            </Button>
          </div>
        </div>

        {/* Features Grid */}
        <div className="grid md:grid-cols-3 gap-6 mb-12">
          <Card className="text-center">
            <CardHeader>
              <Upload className="h-12 w-12 text-primary mx-auto mb-4" />
              <CardTitle>Easy Upload</CardTitle>
              <CardDescription>
                Upload CSV files or enter health data manually through our intuitive interface
              </CardDescription>
            </CardHeader>
          </Card>

          <Card className="text-center">
            <CardHeader>
              <Activity className="h-12 w-12 text-primary mx-auto mb-4" />
              <CardTitle>AI Analysis</CardTitle>
              <CardDescription>
                Get intelligent health insights and risk predictions powered by advanced AI algorithms
              </CardDescription>
            </CardHeader>
          </Card>

          <Card className="text-center">
            <CardHeader>
              <BarChart3 className="h-12 w-12 text-primary mx-auto mb-4" />
              <CardTitle>Visual Reports</CardTitle>
              <CardDescription>
                View your health data through interactive charts and comprehensive summary reports
              </CardDescription>
            </CardHeader>
          </Card>
        </div>

        {/* Sample Data Preview */}
        <Card className="max-w-4xl mx-auto">
          <CardHeader>
            <CardTitle>Sample Health Analysis</CardTitle>
            <CardDescription>Here's what your health report analysis might look like</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="overflow-x-auto">
              <table className="w-full border-collapse">
                <thead>
                  <tr className="border-b">
                    <th className="text-left p-3 font-semibold">Parameter</th>
                    <th className="text-left p-3 font-semibold">Value</th>
                    <th className="text-left p-3 font-semibold">Normal Range</th>
                    <th className="text-left p-3 font-semibold">Status</th>
                  </tr>
                </thead>
                <tbody>
                  <tr className="border-b">
                    <td className="p-3">Blood Pressure</td>
                    <td className="p-3 font-mono">150/95</td>
                    <td className="p-3 text-muted-foreground">120/80</td>
                    <td className="p-3">
                      <span className="px-2 py-1 rounded-full text-xs bg-destructive/10 text-destructive">High</span>
                    </td>
                  </tr>
                  <tr className="border-b">
                    <td className="p-3">Glucose</td>
                    <td className="p-3 font-mono">180 mg/dL</td>
                    <td className="p-3 text-muted-foreground">70-140 mg/dL</td>
                    <td className="p-3">
                      <span className="px-2 py-1 rounded-full text-xs bg-destructive/10 text-destructive">High</span>
                    </td>
                  </tr>
                  <tr>
                    <td className="p-3">Cholesterol</td>
                    <td className="p-3 font-mono">220 mg/dL</td>
                    <td className="p-3 text-muted-foreground">{"<200 mg/dL"}</td>
                    <td className="p-3">
                      <span className="px-2 py-1 rounded-full text-xs bg-yellow-100 text-yellow-800">Borderline</span>
                    </td>
                  </tr>
                </tbody>
              </table>
            </div>
          </CardContent>
        </Card>
      </main>
    </div>
  )
}
