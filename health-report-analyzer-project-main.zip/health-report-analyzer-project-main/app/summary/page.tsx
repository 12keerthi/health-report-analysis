"use client"

import { useEffect, useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Separator } from "@/components/ui/separator"
import { ArrowLeft, Download, FileText, Calendar, User, Activity } from "lucide-react"
import Link from "next/link"
import { useRouter } from "next/navigation"

interface HealthData {
  patientId: string
  bloodPressure: string
  glucose: string
  cholesterol: string
  age: string
  symptoms?: string
}

interface HealthSummary {
  overallRisk: "low" | "moderate" | "high"
  keyFindings: string[]
  recommendations: string[]
  followUpActions: string[]
}

export default function SummaryPage() {
  const [healthData, setHealthData] = useState<HealthData[]>([])
  const [currentPatient, setCurrentPatient] = useState(0)
  const [loading, setLoading] = useState(true)
  const router = useRouter()

  useEffect(() => {
    const storedData = localStorage.getItem("healthData")
    if (storedData) {
      setHealthData(JSON.parse(storedData))
    } else {
      router.push("/")
    }
    setLoading(false)
  }, [router])

  if (loading) {
    return <div className="min-h-screen bg-background flex items-center justify-center">Loading...</div>
  }

  if (healthData.length === 0) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <Card className="max-w-md">
          <CardHeader>
            <CardTitle>No Data Found</CardTitle>
            <CardDescription>Please upload or enter health data first.</CardDescription>
          </CardHeader>
          <CardContent>
            <Button asChild>
              <Link href="/">Go Back Home</Link>
            </Button>
          </CardContent>
        </Card>
      </div>
    )
  }

  const patient = healthData[currentPatient]

  // Generate health summary
  const generateSummary = (): HealthSummary => {
    const [systolic, diastolic] = patient.bloodPressure.split("/").map(Number)
    const glucose = Number(patient.glucose)
    const cholesterol = Number(patient.cholesterol)

    const keyFindings: string[] = []
    const recommendations: string[] = []
    const followUpActions: string[] = []
    let riskCount = 0

    // Blood pressure analysis
    if (systolic >= 140 || diastolic >= 90) {
      keyFindings.push(`Blood pressure (${patient.bloodPressure}) is significantly elevated, indicating hypertension.`)
      recommendations.push("Monitor blood pressure daily and reduce sodium intake.")
      followUpActions.push("Schedule appointment with cardiologist within 2 weeks.")
      riskCount++
    } else if (systolic >= 130 || diastolic >= 80) {
      keyFindings.push(`Blood pressure (${patient.bloodPressure}) is elevated above normal range.`)
      recommendations.push("Implement lifestyle changes including regular exercise and stress management.")
      riskCount++
    } else {
      keyFindings.push(`Blood pressure (${patient.bloodPressure}) is within normal range.`)
    }

    // Glucose analysis
    if (glucose >= 126) {
      keyFindings.push(`Glucose level (${glucose} mg/dL) suggests possible diabetes.`)
      recommendations.push("Follow a low-carbohydrate diet and monitor blood sugar regularly.")
      followUpActions.push("Consult with endocrinologist for diabetes management plan.")
      riskCount++
    } else if (glucose >= 100) {
      keyFindings.push(`Glucose level (${glucose} mg/dL) indicates prediabetes risk.`)
      recommendations.push("Adopt a balanced diet with limited refined sugars and increase physical activity.")
      riskCount++
    } else {
      keyFindings.push(`Glucose level (${glucose} mg/dL) is within normal range.`)
    }

    // Cholesterol analysis
    if (cholesterol >= 240) {
      keyFindings.push(`Cholesterol level (${cholesterol} mg/dL) is high and increases cardiovascular risk.`)
      recommendations.push("Follow a heart-healthy diet low in saturated fats and consider medication.")
      followUpActions.push("Schedule lipid panel recheck in 6-8 weeks.")
      riskCount++
    } else if (cholesterol >= 200) {
      keyFindings.push(`Cholesterol level (${cholesterol} mg/dL) is borderline high.`)
      recommendations.push("Increase fiber intake and incorporate omega-3 rich foods.")
      riskCount++
    } else {
      keyFindings.push(`Cholesterol level (${cholesterol} mg/dL) is within desirable range.`)
    }

    // Age-related considerations
    const age = Number(patient.age)
    if (age >= 50) {
      recommendations.push("Consider annual comprehensive health screenings due to age.")
    }

    // Symptoms consideration
    if (patient.symptoms && patient.symptoms.trim()) {
      keyFindings.push(`Patient reports symptoms: ${patient.symptoms}`)
      followUpActions.push("Discuss reported symptoms with healthcare provider.")
    }

    // General recommendations
    if (riskCount === 0) {
      recommendations.push("Continue maintaining healthy lifestyle habits.")
      recommendations.push("Schedule routine health checkups annually.")
    } else {
      recommendations.push("Implement comprehensive lifestyle modifications.")
      followUpActions.push("Schedule follow-up appointment with primary care physician within 4 weeks.")
    }

    const overallRisk: "low" | "moderate" | "high" = riskCount >= 2 ? "high" : riskCount === 1 ? "moderate" : "low"

    return {
      overallRisk,
      keyFindings,
      recommendations,
      followUpActions,
    }
  }

  const summary = generateSummary()

  const generatePlainLanguageSummary = (): string => {
    const [systolic] = patient.bloodPressure.split("/").map(Number)
    const glucose = Number(patient.glucose)
    const cholesterol = Number(patient.cholesterol)

    let summaryText = `Based on your health data analysis, here's what we found: `

    // Blood pressure
    if (systolic >= 140) {
      summaryText += `Your blood pressure (${patient.bloodPressure}) is higher than normal, indicating a risk of hypertension. `
    } else if (systolic >= 130) {
      summaryText += `Your blood pressure (${patient.bloodPressure}) is slightly elevated. `
    } else {
      summaryText += `Your blood pressure (${patient.bloodPressure}) is in a healthy range. `
    }

    // Glucose
    if (glucose >= 126) {
      summaryText += `Your glucose level (${glucose} mg/dL) is elevated, suggesting possible diabetes. `
    } else if (glucose >= 100) {
      summaryText += `Your glucose level (${glucose} mg/dL) indicates a risk for prediabetes. `
    } else {
      summaryText += `Your glucose level (${glucose} mg/dL) is normal. `
    }

    // Cholesterol
    if (cholesterol >= 240) {
      summaryText += `Your cholesterol (${cholesterol} mg/dL) is high, which increases your risk of heart disease. `
    } else if (cholesterol >= 200) {
      summaryText += `Your cholesterol (${cholesterol} mg/dL) is borderline high. `
    } else {
      summaryText += `Your cholesterol (${cholesterol} mg/dL) is at a healthy level. `
    }

    // Overall recommendation
    if (summary.overallRisk === "high") {
      summaryText += `Overall, your health parameters indicate a high risk that requires immediate attention. Please consult with a healthcare professional as soon as possible to discuss treatment options and lifestyle changes.`
    } else if (summary.overallRisk === "moderate") {
      summaryText += `Overall, your health parameters show moderate risk factors that can be improved with lifestyle changes. Consider consulting with a healthcare professional to develop a personalized health plan.`
    } else {
      summaryText += `Overall, your health parameters look good. Continue maintaining your healthy lifestyle and schedule regular checkups with your healthcare provider.`
    }

    return summaryText
  }

  const plainLanguageSummary = generatePlainLanguageSummary()

  const handleDownloadPDF = () => {
    // Create a simple text-based PDF content
    const pdfContent = `
HEALTH REPORT SUMMARY
Generated on: ${new Date().toLocaleDateString()}

PATIENT INFORMATION:
Patient ID: ${patient.patientId}
Age: ${patient.age} years

HEALTH PARAMETERS:
Blood Pressure: ${patient.bloodPressure}
Glucose: ${patient.glucose} mg/dL
Cholesterol: ${patient.cholesterol} mg/dL
${patient.symptoms ? `Symptoms: ${patient.symptoms}` : ""}

ANALYSIS SUMMARY:
${plainLanguageSummary}

KEY FINDINGS:
${summary.keyFindings.map((finding, index) => `${index + 1}. ${finding}`).join("\n")}

RECOMMENDATIONS:
${summary.recommendations.map((rec, index) => `${index + 1}. ${rec}`).join("\n")}

FOLLOW-UP ACTIONS:
${summary.followUpActions.map((action, index) => `${index + 1}. ${action}`).join("\n")}

OVERALL RISK LEVEL: ${summary.overallRisk.toUpperCase()}

DISCLAIMER:
This report is generated by AI and is for informational purposes only. 
It should not replace professional medical advice, diagnosis, or treatment. 
Always consult with qualified healthcare professionals for medical concerns.
    `

    // Create and download the file
    const blob = new Blob([pdfContent], { type: "text/plain" })
    const url = URL.createObjectURL(blob)
    const a = document.createElement("a")
    a.href = url
    a.download = `health-summary-${patient.patientId}-${new Date().toISOString().split("T")[0]}.txt`
    document.body.appendChild(a)
    a.click()
    document.body.removeChild(a)
    URL.revokeObjectURL(url)
  }

  const getRiskColor = (risk: string) => {
    switch (risk) {
      case "high":
        return "bg-destructive/10 text-destructive border-destructive/20"
      case "moderate":
        return "bg-yellow-100 text-yellow-800 border-yellow-200"
      case "low":
        return "bg-primary/10 text-primary border-primary/20"
      default:
        return "bg-muted text-muted-foreground"
    }
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b bg-card/50 backdrop-blur-sm">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <Button variant="ghost" size="sm" asChild>
                <Link href="/visualization">
                  <ArrowLeft className="h-4 w-4 mr-2" />
                  Back to Visualizations
                </Link>
              </Button>
              <h1 className="text-2xl font-bold text-foreground">Health Summary Report</h1>
            </div>
            {healthData.length > 1 && (
              <div className="flex items-center gap-2">
                <span className="text-sm text-muted-foreground">Patient:</span>
                <select
                  value={currentPatient}
                  onChange={(e) => setCurrentPatient(Number(e.target.value))}
                  className="px-3 py-1 border rounded-md bg-background"
                >
                  {healthData.map((_, index) => (
                    <option key={index} value={index}>
                      {healthData[index].patientId}
                    </option>
                  ))}
                </select>
              </div>
            )}
          </div>
        </div>
      </header>

      <main className="container mx-auto px-4 py-8 max-w-4xl">
        {/* Report Header */}
        <Card className="mb-8">
          <CardHeader>
            <div className="flex items-center justify-between">
              <div>
                <CardTitle className="flex items-center gap-2">
                  <FileText className="h-6 w-6 text-primary" />
                  AI Health Report Summary
                </CardTitle>
                <CardDescription className="flex items-center gap-4 mt-2">
                  <span className="flex items-center gap-1">
                    <User className="h-4 w-4" />
                    Patient ID: {patient.patientId}
                  </span>
                  <span className="flex items-center gap-1">
                    <Calendar className="h-4 w-4" />
                    Generated: {new Date().toLocaleDateString()}
                  </span>
                </CardDescription>
              </div>
              <Badge className={getRiskColor(summary.overallRisk)}>{summary.overallRisk.toUpperCase()} RISK</Badge>
            </div>
          </CardHeader>
        </Card>

        {/* Plain Language Summary */}
        <Card className="mb-8">
          <CardHeader>
            <CardTitle>Executive Summary</CardTitle>
            <CardDescription>AI-generated health assessment in plain language</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="prose prose-sm max-w-none">
              <p className="text-foreground leading-relaxed">{plainLanguageSummary}</p>
            </div>
          </CardContent>
        </Card>

        <div className="grid lg:grid-cols-2 gap-8">
          {/* Key Findings */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Activity className="h-5 w-5 text-primary" />
                Key Findings
              </CardTitle>
            </CardHeader>
            <CardContent>
              <ul className="space-y-3">
                {summary.keyFindings.map((finding, index) => (
                  <li key={index} className="flex items-start gap-3">
                    <span className="flex-shrink-0 w-6 h-6 bg-primary/10 text-primary rounded-full flex items-center justify-center text-sm font-medium">
                      {index + 1}
                    </span>
                    <span className="text-sm leading-relaxed">{finding}</span>
                  </li>
                ))}
              </ul>
            </CardContent>
          </Card>

          {/* Recommendations */}
          <Card>
            <CardHeader>
              <CardTitle>Recommendations</CardTitle>
            </CardHeader>
            <CardContent>
              <ul className="space-y-3">
                {summary.recommendations.map((recommendation, index) => (
                  <li key={index} className="flex items-start gap-3">
                    <span className="flex-shrink-0 w-6 h-6 bg-accent/10 text-accent rounded-full flex items-center justify-center text-sm font-medium">
                      {index + 1}
                    </span>
                    <span className="text-sm leading-relaxed">{recommendation}</span>
                  </li>
                ))}
              </ul>
            </CardContent>
          </Card>
        </div>

        {/* Follow-up Actions */}
        {summary.followUpActions.length > 0 && (
          <Card className="mt-8">
            <CardHeader>
              <CardTitle>Follow-up Actions Required</CardTitle>
              <CardDescription>Important next steps for your health</CardDescription>
            </CardHeader>
            <CardContent>
              <ul className="space-y-3">
                {summary.followUpActions.map((action, index) => (
                  <li key={index} className="flex items-start gap-3">
                    <span className="flex-shrink-0 w-6 h-6 bg-destructive/10 text-destructive rounded-full flex items-center justify-center text-sm font-medium">
                      !
                    </span>
                    <span className="text-sm leading-relaxed font-medium">{action}</span>
                  </li>
                ))}
              </ul>
            </CardContent>
          </Card>
        )}

        <Separator className="my-8" />

        {/* Disclaimer */}
        <Card className="bg-muted/50">
          <CardContent className="pt-6">
            <p className="text-sm text-muted-foreground text-center">
              <strong>Medical Disclaimer:</strong> This report is generated by AI and is for informational purposes
              only. It should not replace professional medical advice, diagnosis, or treatment. Always consult with
              qualified healthcare professionals regarding any medical concerns or before making any changes to your
              health regimen.
            </p>
          </CardContent>
        </Card>

        {/* Action Buttons */}
        <div className="flex flex-col sm:flex-row gap-4 justify-center mt-8">
          <Button onClick={handleDownloadPDF} size="lg">
            <Download className="mr-2 h-5 w-5" />
            Download Summary Report
          </Button>
          <Button asChild variant="outline" size="lg">
            <Link href="/">Start New Analysis</Link>
          </Button>
        </div>
      </main>
    </div>
  )
}
