"use client"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Activity, BarChart3, FileText, Brain } from "lucide-react"
import Link from "next/link"

export default function HomePage() {
  const scrollToFeatures = () => {
    document.getElementById("features")?.scrollIntoView({ behavior: "smooth" })
  }

  return (
    <div className="min-h-screen bg-background">
      <header className="border-b bg-card/50 backdrop-blur-sm">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <Activity className="h-8 w-8 text-primary" />
              <h1 className="text-2xl font-bold text-foreground">AI Health Report Analyzer</h1>
            </div>
            <nav className="hidden md:flex items-center gap-6">
              <Link href="/" className="text-foreground hover:text-primary transition-colors">
                Home
              </Link>
              <Link href="#about" className="text-foreground hover:text-primary transition-colors">
                About
              </Link>
              <Link href="#features" className="text-foreground hover:text-primary transition-colors">
                Features
              </Link>
              <Button variant="outline" asChild>
                <Link href="/login">Login</Link>
              </Button>
            </nav>
          </div>
        </div>
      </header>

      <main>
        <section className="container mx-auto px-4 py-20 text-center">
          <h2 className="text-5xl font-bold text-foreground mb-6 text-balance">Smarter Health Reports with AI</h2>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto mb-8">
            Quickly analyze, interpret, and understand your health reports using Artificial Intelligence.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button size="lg" className="text-lg px-8 py-6" asChild>
              <Link href="/login">Get Started</Link>
            </Button>
            <Button size="lg" variant="outline" className="text-lg px-8 py-6 bg-transparent" onClick={scrollToFeatures}>
              Learn More
            </Button>
          </div>
        </section>

        <section id="features" className="bg-muted/30 py-20">
          <div className="container mx-auto px-4">
            <h3 className="text-3xl font-bold text-center mb-12">Features</h3>
            <div className="grid md:grid-cols-3 gap-8 max-w-6xl mx-auto">
              <Card className="text-center">
                <CardHeader>
                  <Brain className="h-12 w-12 text-primary mx-auto mb-4" />
                  <CardTitle className="text-xl">Automated Report Analysis</CardTitle>
                </CardHeader>
                <CardContent>
                  <CardDescription className="text-base">
                    AI detects anomalies in health parameters automatically, saving time and improving accuracy.
                  </CardDescription>
                </CardContent>
              </Card>

              <Card className="text-center">
                <CardHeader>
                  <BarChart3 className="h-12 w-12 text-primary mx-auto mb-4" />
                  <CardTitle className="text-xl">Visual Dashboards</CardTitle>
                </CardHeader>
                <CardContent>
                  <CardDescription className="text-base">
                    See health data as easy-to-read charts and interactive visualizations.
                  </CardDescription>
                </CardContent>
              </Card>

              <Card className="text-center">
                <CardHeader>
                  <FileText className="h-12 w-12 text-primary mx-auto mb-4" />
                  <CardTitle className="text-xl">Plain Language Summaries</CardTitle>
                </CardHeader>
                <CardContent>
                  <CardDescription className="text-base">
                    Simple explanations for patients to understand their health reports easily.
                  </CardDescription>
                </CardContent>
              </Card>
            </div>
          </div>
        </section>

        <section id="about" className="py-20">
          <div className="container mx-auto px-4 max-w-4xl text-center">
            <h3 className="text-3xl font-bold mb-8">About</h3>
            <p className="text-lg text-muted-foreground leading-relaxed">
              Manual health report review is slow and prone to errors. Our AI-powered system helps doctors make faster
              and more accurate decisions, while helping patients better understand their health. By leveraging advanced
              artificial intelligence, we transform complex medical data into actionable insights that benefit
              healthcare providers, patients, and researchers alike.
            </p>
          </div>
        </section>

        <section className="bg-primary/5 py-20">
          <div className="container mx-auto px-4 text-center">
            <h3 className="text-3xl font-bold text-foreground mb-6">Ready to analyze your reports with AI?</h3>
            <Button size="lg" className="text-lg px-8 py-6" asChild>
              <Link href="/login">Login to Continue</Link>
            </Button>
          </div>
        </section>
      </main>

      <footer className="border-t bg-muted/30 py-8">
        <div className="container mx-auto px-4">
          <div className="flex flex-col md:flex-row justify-between items-center gap-4">
            <div className="flex gap-6">
              <Link href="#" className="text-muted-foreground hover:text-foreground transition-colors">
                Privacy Policy
              </Link>
              <Link href="#" className="text-muted-foreground hover:text-foreground transition-colors">
                Terms of Service
              </Link>
              <Link href="#" className="text-muted-foreground hover:text-foreground transition-colors">
                Contact
              </Link>
            </div>
            <p className="text-muted-foreground">Copyright © 2025 Health AI</p>
          </div>
        </div>
      </footer>
    </div>
  )
}
